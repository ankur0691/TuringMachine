/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingsubtractor;

/**
 * This class implements main method
 * @author ankur
 */
public class TuringSubtractor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Turing machine1 = new Turing(7);    // A seven state machine
        State s0 = new State(0);                
        State s1 = new State(1);  
        State s2 = new State(2);                 
        State s3 = new State(3);
        State s4 = new State(4);                 
        State s5 = new State(5);
        //Begin. Replace the leading 0 by B.
        s0.addTransition(new Transition('0','B',Transition.RIGHT,1));
        //Search right looking for the first 1.
        s1.addTransition(new Transition('0','0',Transition.RIGHT,1));
        s1.addTransition(new Transition('1','1',Transition.RIGHT,2));
        //Search right past 1’s until encountering a 0. Change that 0 to 1.
        s2.addTransition(new Transition('1','1',Transition.RIGHT,2));
        s2.addTransition(new Transition('0','1',Transition.LEFT,3));
        //Move left to a blank. Enter state q0 to repeat the cycle.
        s3.addTransition(new Transition('0','0',Transition.LEFT,3));
        s3.addTransition(new Transition('1','1',Transition.LEFT,3));
        s3.addTransition(new Transition('B','B',Transition.RIGHT,0));

        //If in state q2 a B is encountered before a 0, we have situation i 
        //described above. Enter state q4 and move left, changing all 1’s 
        //to B’s until encountering a B. This B is changed back to a 0, 
        //state q6 is entered and M halts.
        
        s2.addTransition(new Transition('B','B',Transition.LEFT,4));
        s4.addTransition(new Transition('1','B',Transition.LEFT,4));
        s4.addTransition(new Transition('0','0',Transition.LEFT,4));
        s4.addTransition(new Transition('B','0',Transition.RIGHT,6));
        //If in state q0 a 1 is encountered instead of a 0, the first block 
        //of 0’s has been exhausted, as in situation (ii) above. M enters 
        //state q5 to erase the rest of the tape, then enters q6 and halts. 
        s0.addTransition(new Transition('1','B',Transition.RIGHT,5));
        s5.addTransition(new Transition('0','B',Transition.RIGHT,5));
        s5.addTransition(new Transition('1','B',Transition.RIGHT,5));
        s5.addTransition(new Transition('B','B',Transition.RIGHT,6));
        
        machine1.addState(s0);                 // Add the states to the machine
        machine1.addState(s1);
        machine1.addState(s2);
        machine1.addState(s3);
        machine1.addState(s4);
        machine1.addState(s5);
        String inTape = "00000100";     // Define some input

        System.out.println(inTape);

        String outTape = machine1.execute(inTape);  // Execute the machine

        System.out.println(outTape);  // Show the machine’s output

    }
    
}
