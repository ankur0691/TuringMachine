/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingdecider;

/**
 * This class represents a turing machine to add states and implement execute
 * @author ankur
 */
public class Turing {
    public static final int TAPE_LENGTH=100;
    private State states[];
    public Turing(int numOfState){
        states = new State[numOfState];
        
    }
    
    public void addState(State thisState){
        states[thisState.getStateId()] = thisState;
    }
    
    public String execute(String input){
        //intialize input array and end it with a B to be safe
        char input1[] = new char[input.length()+1];
        int i;
        for(i=0;i<input.length();i++)
            input1[i] = input.charAt(i);
        input1[input.length()] = 'B';
        
        //intialize an output String with all B's
        char output[] = new char[TAPE_LENGTH];
        for(i=1;i<TAPE_LENGTH;i++){
                output[i] = 'B';
        }
        //start with state 0
        State currentState = states[0];
        //maintains the position in the input string
        int head=0;
        Transition temp;
        //loop until we have reached a state which does not have any transition for the input
        //means our input string is not correct as per the language
        while(currentState.transitions[input1[head]] !=null){
            temp = currentState.transitions[input1[head]];
            //if we reached the final state, the string is correct!We are done!
            if(temp.getStateId() == states.length - 1)
                return "1" +  new String(output);
            input1[head]= temp.getOutput();
            head = head + temp.getAction();
            currentState = states[temp.getStateId()];
        }
        //if we reach this return statement, our input string is not correct
        return "0" + new String(output);
    }
    
}
