/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingdecider;

import java.util.Scanner;

/**
 * This file has the main file for TuringDecider
 * @author ankur
 */
public class TuringDecider {

     public static void main( String args[]) {
     Turing machine1 = new Turing(5);    // A seven state machine
        State s0 = new State(0);                
        State s1 = new State(1);  
        State s2 = new State(2);                 
        State s3 = new State(3);
        State s4 = new State(4);                 
        //Begin. Replace the leading 0 by X.X is used as a marker to know the last 0 that we found.
        s0.addTransition(new Transition('0','X',Transition.RIGHT,1));
        //Search right looking for the first 1.Y is used to indicate the 1 that has been visited
        s1.addTransition(new Transition('0','0',Transition.RIGHT,1));
        s1.addTransition(new Transition('Y','Y',Transition.RIGHT,1));
        
        //If we found a 1, change it to Y. go to thew state 2 to keep moving left 
        s1.addTransition(new Transition('1','Y',Transition.LEFT,2));
   
        //Keep shifting left to see the next 0
        s2.addTransition(new Transition('0','0',Transition.LEFT,2));
        s2.addTransition(new Transition('Y','Y',Transition.LEFT,2));
        
        //If we encounter X, go back to state 0 to start again looking for the next 0
        s2.addTransition(new Transition('X','X',Transition.RIGHT,0));
        
        //If we encounter a Y after state 0. means we have matched all 0's and 1's so go to state 3 and keep shifting right to check ther is no 0,1 left.
        s0.addTransition(new Transition('Y','Y',Transition.RIGHT,3));
        s3.addTransition(new Transition('Y','Y',Transition.RIGHT,3));
        //if we encounter B instead, means we are done
        s3.addTransition(new Transition('B','B',Transition.RIGHT,4));

        
        machine1.addState(s0);                 // Add the states to the machine
        machine1.addState(s1);
        machine1.addState(s2);
        machine1.addState(s3);
        machine1.addState(s4);
        Scanner reader = new Scanner(System.in);     // Define some input
        String inTape = reader.next();
        String outTape = machine1.execute(inTape);  // Execute the machine

        System.out.println(outTape);  // Show the machine’s output

    }
       
    
}
