/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingdecider;

/**
 * This class implements the state
 * @author ankur
 */
public class State {
    private int stateId;
   
    //stores all the transitions for this state, indexed based on the character(256 possible)
    public Transition transitions[];
    public State(int stateId){
        this.stateId = stateId;
        this.transitions = new Transition[256];
    }
    
    
    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public Transition[] getTransitions() {
        return transitions;
    }

    public void setTransitions(Transition[] transitions) {
        this.transitions = transitions;
    }
    
    public void addTransition(Transition train){
        transitions[train.getInput()] = train;
    }
    
    
    
}
