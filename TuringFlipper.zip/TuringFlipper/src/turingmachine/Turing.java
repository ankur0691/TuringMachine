/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingmachine;

/**
 * This class contains the turing machine implementation with all states and execute method
 * @author ankur
 */
public class Turing {
    public static final int TAPE_LENGTH=100;
    //to store all the states in this machine
    private State states[];
    public Turing(int numOfState){
        states = new State[numOfState];
        
    }
    
    public void addState(State thisState){
        states[thisState.getStateId()] = thisState;
    }
    
    public String execute(String input){
        //intialize an output String with input string followed by B's
        char output[] = new char[TAPE_LENGTH];
        for(int i=0;i<TAPE_LENGTH;i++){
            if(i<input.length())
                output[i] = input.charAt(i);
            else
                output[i] = 'B'; 
        }
        //start with 0th state
        State currentState = states[0]; 
        int head=0;
        
        //while we have not reached the final state or no possible transition, keep iterating
        while(currentState.transitions[output[head]] !=null){
            Transition temp = currentState.transitions[output[head]];
            output[head]= temp.getOutput();
            head = head + temp.getAction();
            if(temp.getStateId() == states.length-1)
                break;
            else
                currentState = states[temp.getStateId()];
        }
        return new String(output);
    }
    
}
