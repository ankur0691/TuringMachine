/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingmachine;

/**
 * This class implements the states of a machine
 * @author ankur
 */
public class State {
    private int stateId;
    //contains all the transitions from this state, indexed based on all the possible 256 characters
    public Transition transitions[];
    public State(int stateId){
        this.stateId = stateId;
        this.transitions = new Transition[256];
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public Transition[] getTransitions() {
        return transitions;
    }

    public void setTransitions(Transition[] transitions) {
        this.transitions = transitions;
    }
    
    public void addTransition(Transition train){
        transitions[train.getInput()] = train;
    }
    
    
    
}
