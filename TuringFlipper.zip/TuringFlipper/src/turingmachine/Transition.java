/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingmachine;

/**
 * This class implements the transition details  
 * @author ankur
 */
public class Transition {
    public static final int RIGHT = 1;
    public static final int LEFT = -1;
    private char input;
    private char output;
    private int action;
    private int stateId;
    public Transition(char input, char output, int action, int stateId){
        this.input = input;
        this.output = output;
        this.action = action;
        this.stateId = stateId;
    }
    
    public char getInput() {
        return input;
    }

    public char getOutput() {
        return output;
    }

    public int getAction() {
        return action;
    }

    public int getStateId() {
        return stateId;
    }

}
